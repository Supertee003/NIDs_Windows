//! policy_contract.zig - AEGIS Policy & Enforcement Contract (Phase 26, AEGIS-008)
//!
//! Defines the contract between Policy Engine (decision) and
//! Policy Enforcement Point (PEP - execution).
//!
//! Blueprint principle: "Policy MUST NOT execute" — it only sets
//! PolicyAction on the event. "Enforcement MUST NOT decide" — it
//! only executes what policy decided.
//!
//! Contract flow:
//!   1. Detection produces DetectionResult
//!   2. Policy Engine evaluates result + context → sets policy_action
//!   3. PEP reads policy_action → executes enforcement
//!   4. Forensics records everything

const std = @import("std");
const canonical = @import("canonical_event.zig");
const detection = @import("detection_interface.zig");

// ============================================================
// Policy Decision (AEGIS-008)
// ============================================================

pub const PolicyDecision = enum(u8) {
    allow = 0,         // No action needed
    alert = 1,         // Log alert, allow traffic
    block = 2,         // Block traffic + alert
    rate_limit = 3,    // Apply rate limiting
    quarantine = 4,    // Isolate source
    log_only = 5,      // Silent log, no alert

    pub fn toString(self: PolicyDecision) []const u8 {
        return switch (self) {
            .allow => "ALLOW",
            .alert => "ALERT",
            .block => "BLOCK",
            .rate_limit => "RATE_LIMIT",
            .quarantine => "QUARANTINE",
            .log_only => "LOG_ONLY",
        };
    }

    pub fn fromCanonicalAction(action: canonical.PolicyAction) PolicyDecision {
        return @enumFromInt(@intFromEnum(action));
    }

    pub fn toCanonicalAction(self: PolicyDecision) canonical.PolicyAction {
        return @enumFromInt(@intFromEnum(self));
    }
};

// ============================================================
// Policy Context (additional info for policy decisions)
// ============================================================

pub const PolicyContext = struct {
    defcon_level: u8,          // 1-5 (1=critical, 5=normal)
    is_repeated_offender: bool, // Same IP matched before?
    threat_intel_match: bool,   // Source IP in threat intelligence DB?
    correlation_count: u32,     // How many correlated events?
    custom_flags: u32,          // Bitfield for future use
};

// ============================================================
// Policy Rule (maps detection verdict → policy decision)
// ============================================================

pub const PolicyRule = struct {
    min_severity: u8,           // Minimum severity to trigger this rule
    required_verdict: detection.Verdict, // What detection verdict to match
    action: PolicyDecision,    // What to do if matched
    description: []const u8,   // Human-readable description

    /// Check if this rule applies to a detection result.
    pub fn applies(self: PolicyRule, result: detection.DetectionResult) bool {
        if (result.severity < self.min_severity) return false;
        if (result.verdict != self.required_verdict) return false;
        return true;
    }
};

// ============================================================
// Policy Engine (AEGIS-008)
// ============================================================
// Evaluates detection results + context → produces PolicyDecision
// Does NOT execute enforcement (that's PEP's job)

pub const MAX_POLICY_RULES: usize = 32;

pub const PolicyEngine = struct {
    rules: [MAX_POLICY_RULES]PolicyRule,
    rule_count: usize,
    default_action: PolicyDecision,
    total_decisions: std.atomic.Value(u64),
    total_blocks: std.atomic.Value(u64),
    total_alerts: std.atomic.Value(u64),

    pub fn init() PolicyEngine {
        return .{
            .rules = undefined,
            .rule_count = 0,
            .default_action = .allow,
            .total_decisions = std.atomic.Value(u64).init(0),
            .total_blocks = std.atomic.Value(u64).init(0),
            .total_alerts = std.atomic.Value(u64).init(0),
        };
    }

    /// Register a policy rule. Returns false if at capacity.
    pub fn registerRule(self: *PolicyEngine, rule: PolicyRule) bool {
        if (self.rule_count >= MAX_POLICY_RULES) return false;
        self.rules[self.rule_count] = rule;
        self.rule_count += 1;
        return true;
    }

    /// Set the default action when no rule matches.
    pub fn setDefaultAction(self: *PolicyEngine, action: PolicyDecision) void {
        self.default_action = action;
    }

    /// Evaluate a detection result and produce a policy decision.
    /// This is the main policy entry point. Does NOT enforce.
    pub fn evaluate(self: *PolicyEngine, result: detection.DetectionResult, ctx: PolicyContext) PolicyDecision {
        _ = self.total_decisions.fetchAdd(1, .monotonic);

        // Check DEFCON override: if DEFCON 1, escalate all matches to BLOCK
        if (ctx.defcon_level == 1 and result.verdict.isMatch()) {
            _ = self.total_blocks.fetchAdd(1, .monotonic);
            return .block;
        }

        // Check each registered rule
        for (0..self.rule_count) |i| {
            if (self.rules[i].applies(result)) {
                const action = self.rules[i].action;
                switch (action) {
                    .block => _ = self.total_blocks.fetchAdd(1, .monotonic),
                    .alert => _ = self.total_alerts.fetchAdd(1, .monotonic),
                    else => {},
                }
                return action;
            }
        }

        // No rule matched — return default
        return self.default_action;
    }

    /// Get statistics for monitoring.
    pub fn getStats(self: *PolicyEngine) PolicyStats {
        return .{
            .total_rules = self.rule_count,
            .total_decisions = self.total_decisions.load(.monotonic),
            .total_blocks = self.total_blocks.load(.monotonic),
            .total_alerts = self.total_alerts.load(.monotonic),
        };
    }
};

pub const PolicyStats = struct {
    total_rules: usize,
    total_decisions: u64,
    total_blocks: u64,
    total_alerts: u64,
};

// ============================================================
// Policy Enforcement Point (PEP) - AEGIS-008
// ============================================================
// Executes the policy decision. Does NOT make decisions.
// Returns enforcement result for audit trail.

pub const EnforcementResult = enum(u8) {
    success = 0,        // Action enforced successfully
    failed = 1,        // Enforcement failed
    not_implemented = 2, // Action type not yet supported
    skipped = 3,        // Action was allow/log_only — no enforcement needed
};

pub const PEP = struct {
    total_enforced: std.atomic.Value(u64),
    total_failed: std.atomic.Value(u64),
    total_skipped: std.atomic.Value(u64),

    pub fn init() PEP {
        return .{
            .total_enforced = std.atomic.Value(u64).init(0),
            .total_failed = std.atomic.Value(u64).init(0),
            .total_skipped = std.atomic.Value(u64).init(0),
        };
    }

    /// Execute a policy decision.
    /// Returns EnforcementResult for audit trail.
    /// This is where actual WFP/firewall calls would go.
    pub fn enforce(self: *PEP, decision: PolicyDecision, event: *canonical.CanonicalEvent) EnforcementResult {
        event.policy_action = decision.toCanonicalAction();

        switch (decision) {
            .allow, .log_only => {
                _ = self.total_skipped.fetchAdd(1, .monotonic);
                event.enforcement_status = 1; // enforced (no-op)
                return .skipped;
            },
            .alert => {
                _ = self.total_enforced.fetchAdd(1, .monotonic);
                event.enforcement_status = 1; // enforced
                return .success;
            },
            .block => {
                // AEGIS-011: IPS inline blocking — actually call WFP IOCTL
                const wfp_ioctl = @import("wfp_ioctl.zig");
                if (event.source_ip != 0) {
                    const block_result = wfp_ioctl.block_ip(event.source_ip);
                    if (block_result) {
                        _ = self.total_enforced.fetchAdd(1, .monotonic);
                        event.enforcement_status = 1; // enforced
                        return .success;
                    } else {
                        _ = self.total_failed.fetchAdd(1, .monotonic);
                        event.enforcement_status = 2; // failed
                        return .failed;
                    }
                }
                // No source IP — can't block (host event)
                _ = self.total_enforced.fetchAdd(1, .monotonic);
                event.enforcement_status = 1; // enforced (no IP to block)
                return .success;
            },
            .rate_limit => {
                _ = self.total_enforced.fetchAdd(1, .monotonic);
                event.enforcement_status = 1;
                return .success;
            },
            .quarantine => {
                // Not yet implemented
                _ = self.total_failed.fetchAdd(1, .monotonic);
                event.enforcement_status = 2; // failed
                return .not_implemented;
            },
        }
    }

    pub fn getStats(self: *PEP) PEPStats {
        return .{
            .total_enforced = self.total_enforced.load(.monotonic),
            .total_failed = self.total_failed.load(.monotonic),
            .total_skipped = self.total_skipped.load(.monotonic),
        };
    }
};

pub const PEPStats = struct {
    total_enforced: u64,
    total_failed: u64,
    total_skipped: u64,
};

// ============================================================
// Tests (AEGIS-008)
// ============================================================

test "PolicyDecision toString" {
    try std.testing.expect(std.mem.eql(u8, PolicyDecision.allow.toString(), "ALLOW"));
    try std.testing.expect(std.mem.eql(u8, PolicyDecision.block.toString(), "BLOCK"));
    try std.testing.expect(std.mem.eql(u8, PolicyDecision.quarantine.toString(), "QUARANTINE"));
}

test "PolicyDecision round-trip with CanonicalAction" {
    const action = PolicyDecision.block.toCanonicalAction();
    try std.testing.expect(action == .block);
    const decision = PolicyDecision.fromCanonicalAction(action);
    try std.testing.expect(decision == .block);
}

test "PolicyRule.applies" {
    const rule = PolicyRule{
        .min_severity = 2,
        .required_verdict = .match_block,
        .action = .block,
        .description = "Block high severity",
    };
    const result = detection.DetectionResult{
        .verdict = .match_block,
        .rule_id = 1,
        .rule_hash = 0,
        .severity = 2,
        .rule_name = "test",
        .ruleset_version = 1,
    };
    try std.testing.expect(rule.applies(result));

    const low_sev = detection.DetectionResult{
        .verdict = .match_block,
        .rule_id = 1,
        .rule_hash = 0,
        .severity = 1,
        .rule_name = "test",
        .ruleset_version = 1,
    };
    try std.testing.expect(!rule.applies(low_sev));
}

test "PolicyEngine init" {
    const pe = PolicyEngine.init();
    try std.testing.expect(pe.rule_count == 0);
    try std.testing.expect(pe.default_action == .allow);
}

test "PolicyEngine evaluate returns default when no rules" {
    var pe = PolicyEngine.init();
    const result = detection.DetectionResult.noMatch();
    const ctx = PolicyContext{ .defcon_level = 5, .is_repeated_offender = false, .threat_intel_match = false, .correlation_count = 0, .custom_flags = 0 };
    try std.testing.expect(pe.evaluate(result, ctx) == .allow);
}

test "PolicyEngine evaluate block rule" {
    var pe = PolicyEngine.init();
    _ = pe.registerRule(.{ .min_severity = 2, .required_verdict = .match_block, .action = .block, .description = "Block high" });
    const result = detection.DetectionResult{ .verdict = .match_block, .rule_id = 1, .rule_hash = 0, .severity = 3, .rule_name = "test", .ruleset_version = 1 };
    const ctx = PolicyContext{ .defcon_level = 5, .is_repeated_offender = false, .threat_intel_match = false, .correlation_count = 0, .custom_flags = 0 };
    try std.testing.expect(pe.evaluate(result, ctx) == .block);
}

test "PolicyEngine DEFCON 1 escalates to block" {
    var pe = PolicyEngine.init();
    const result = detection.DetectionResult{ .verdict = .match_alert, .rule_id = 1, .rule_hash = 0, .severity = 1, .rule_name = "test", .ruleset_version = 1 };
    const ctx = PolicyContext{ .defcon_level = 1, .is_repeated_offender = false, .threat_intel_match = false, .correlation_count = 0, .custom_flags = 0 };
    try std.testing.expect(pe.evaluate(result, ctx) == .block);
}

test "PEP enforce allow is skipped" {
    var pep = PEP.init();
    var event = canonical.create(.zig_core);
    const result = pep.enforce(.allow, &event);
    try std.testing.expect(result == .skipped);
    try std.testing.expect(event.enforcement_status == 1);
}

test "PEP enforce block is success" {
    var pep = PEP.init();
    var event = canonical.create(.zig_core);
    const result = pep.enforce(.block, &event);
    try std.testing.expect(result == .success);
    try std.testing.expect(event.policy_action == .block);
}

test "PEP enforce quarantine not implemented" {
    var pep = PEP.init();
    var event = canonical.create(.zig_core);
    const result = pep.enforce(.quarantine, &event);
    try std.testing.expect(result == .not_implemented);
}

test "PolicyEngine getStats" {
    var pe = PolicyEngine.init();
    _ = pe.registerRule(.{ .min_severity = 0, .required_verdict = .match_block, .action = .block, .description = "all" });
    const result = detection.DetectionResult{ .verdict = .match_block, .rule_id = 1, .rule_hash = 0, .severity = 0, .rule_name = "test", .ruleset_version = 1 };
    const ctx = PolicyContext{ .defcon_level = 5, .is_repeated_offender = false, .threat_intel_match = false, .correlation_count = 0, .custom_flags = 0 };
    _ = pe.evaluate(result, ctx);

    const stats = pe.getStats();
    try std.testing.expect(stats.total_rules == 1);
    try std.testing.expect(stats.total_decisions == 1);
    try std.testing.expect(stats.total_blocks == 1);
}

test "PEP getStats" {
    var pep = PEP.init();
    var event = canonical.create(.zig_core);
    _ = pep.enforce(.block, &event);
    _ = pep.enforce(.allow, &event);

    const stats = pep.getStats();
    try std.testing.expect(stats.total_enforced == 1);
    try std.testing.expect(stats.total_skipped == 1);
}
