const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    // STEP 15: Release build option (default: false = Debug)
    const release_mode = b.option(bool, "release", "Build in ReleaseFast mode") orelse false;
    const final_optimize = if (release_mode) .ReleaseFast else optimize;

    // STEP 15: Version options (override release_info.zig defaults)
    const version_major = b.option(u32, "version_major", "Major version") orelse 2;
    const version_minor = b.option(u32, "version_minor", "Minor version") orelse 0;
    const version_patch = b.option(u32, "version_patch", "Patch version") orelse 0;

    const exe = b.addExecutable(.{
        .name = "aegis-nids",
        .root_source_file = b.path("core/nids_main.zig"),
        .target = target,
        .optimize = final_optimize,
    });

    // STEP 15: Embed version info via build options
    const options = b.addOptions();
    options.addOption(u32, "version_major", version_major);
    options.addOption(u32, "version_minor", version_minor);
    options.addOption(u32, "version_patch", version_patch);
    options.addOption(bool, "release", release_mode);
    exe.root_module.addOptions("aegis_build", options);

    const rules_src = b.path("config/Rules.json");
    const rules_install = b.addInstallFileWithDir(rules_src, .bin, "Rules.json");
    exe.step.dependOn(&rules_install.step);
    b.installFile("config/Rules.json", "Rules.json");

    const run_cmd = b.addRunArtifact(exe);
    run_cmd.step.dependOn(b.getInstallStep());

    const run_step = b.step("run", "Run the app");
    run_step.dependOn(&run_cmd.step);

    // STEP 15: Release target — `zig build release`
    const release_step = b.step("release", "Build release binary (ReleaseFast + version stamping)");
    const release_exe = b.addExecutable(.{
        .name = "aegis-nids",
        .root_source_file = b.path("core/nids_main.zig"),
        .target = target,
        .optimize = .ReleaseFast,
    });
    const release_options = b.addOptions();
    release_options.addOption(u32, "version_major", version_major);
    release_options.addOption(u32, "version_minor", version_minor);
    release_options.addOption(u32, "version_patch", version_patch);
    release_options.addOption(bool, "release", true);
    release_exe.root_module.addOptions("aegis_build", release_options);
    const release_install = b.addInstallArtifact(release_exe, .{
        .dest_dir = .{ .override = .bin },
    });
    release_step.dependOn(&release_install.step);

    // STEP 15: Version target — `zig build version` prints version info
    const version_step = b.step("version", "Print release version info");
    const version_run = b.addRunArtifact(exe);
    version_run.addArg("--version");
    version_step.dependOn(&version_run.step);

    const test_step = b.step("test", "Run unit tests");

    const test_files = [_][]const u8{
        "core/nids_analyze.zig",
        "core/wfp_ioctl.zig",
        "core/pipe_monitor.zig",
        "core/minifilter_reader.zig",
        "core/win32_io.zig",
        "core/forensic_log.zig",
        "core/canonical_event.zig",
        "core/wire_event.zig",
        "core/event_queue.zig",
        "core/priority_queue.zig",
        "core/event_fabric.zig",
        "core/nose_integration.zig",
        "core/flow_integration.zig",
        "core/detection_integration.zig",
        "core/correlation_integration.zig",
        "core/rag_integration.zig",
        "core/policy_integration.zig",
        "core/forensics_integration.zig",
        "core/runtime_golden_path_test.zig",
        "core/perf_benchmark.zig",
        "core/ips_canary_test.zig",
        "core/xdr_hardening.zig",
        "core/release_info.zig",
        "core/nose_contract.zig",
        "core/detection_interface.zig",
        "core/policy_contract.zig",
        "core/golden_path_test.zig",
        "core/hids_process_monitor.zig",
        "core/flow_engine.zig",
        "core/xdr_correlator.zig",
        "core/rag_intelligence.zig",
        "core/policy_ir.zig",
        "core/sprint2_e2e_test.zig",
    };

    for (test_files) |test_file| {
        const tests = b.addTest(.{
            .root_source_file = b.path(test_file),
            .target = target,
            .optimize = optimize,
        });
        const run_tests = b.addRunArtifact(tests);
        test_step.dependOn(&run_tests.step);
    }
}
