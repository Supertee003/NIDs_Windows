//! event_fabric.zig - AEGIS Event Fabric Runtime (STEP 3)
//!
//! Centralized runtime for the Sensor -> Queue -> Detection pipeline.
//! Provides:
//!   1. Backpressure signaling — caller knows when queue approaches capacity
//!   2. Per-event latency tracking — time spent in queue (enqueue -> pop)
//!   3. Depth thresholds — warning/critical levels for ops visibility
//!   4. Drop policy selection — block, drop_oldest, drop_lowest_priority
//!   5. Unified metrics snapshot — single struct for monitoring/CLI
//!
//! This module is the SINGLE source of truth for queue runtime behavior.
//! nose_contract.zig delegates here; nids_main.zig reads metrics from here.
//!
//! Backpressure contract:
//!   - Caller calls submitWithBackpressure() instead of submit()
//!   - On drop, returns SubmitWithPressure{ .accepted=false, .pressure=.high }
//!   - Caller can call currentPressure() before submit to decide sampling
//!   - High pressure => caller should sample/drop non-critical events itself

const std = @import("std");
const canonical = @import("canonical_event.zig");
const wire = @import("wire_event.zig");
const pq = @import("priority_queue.zig");

// ============================================================
// STEP 3: Backpressure levels
// ============================================================

pub const Pressure = enum(u8) {
    /// Queue depth < 50% of capacity — normal operation
    low = 0,
    /// Queue depth 50%..80% of capacity — caller may start sampling
    medium = 1,
    /// Queue depth > 80% of capacity — caller MUST shed load
    high = 2,
    /// Queue depth == capacity — every new event drops
    saturated = 3,

    pub fn toString(self: Pressure) []const u8 {
        return switch (self) {
            .low => "low",
            .medium => "medium",
            .high => "high",
            .saturated => "saturated",
        };
    }
};

// ============================================================
// STEP 3: Drop policy (when queue is full)
// ============================================================

pub const DropPolicy = enum(u8) {
    /// Block the new event (return .dropped). Default.
    block_new = 0,
    /// Drop the oldest event from the same priority, accept the new one
    drop_oldest = 1,
    /// Drop the lowest-priority event anywhere in the queue, accept new
    drop_lowest_priority = 2,
};

// ============================================================
// STEP 3: Fabric configuration
// ============================================================

pub const FabricConfig = struct {
    capacity_per_priority: usize = 256,
    validate_on_submit: bool = true,
    /// Begin emitting medium-pressure signal at this depth fraction (0.0..1.0)
    medium_threshold: f32 = 0.50,
    /// Begin emitting high-pressure signal at this depth fraction (0.0..1.0)
    high_threshold: f32 = 0.80,
    /// Drop policy when queue is full
    drop_policy: DropPolicy = .block_new,
    // Note: validate_on_submit is honored for in-process events;
    // wire-format events always require valid magic regardless.
};

// ============================================================
// STEP 3: Unified metrics snapshot
// ============================================================

pub const FabricMetrics = struct {
    initialized: bool,
    /// Total events currently in queue (all priorities)
    pending: usize,
    /// Per-priority breakdown
    high_pending: usize,
    normal_pending: usize,
    low_pending: usize,
    /// Capacity per priority
    capacity_per_priority: usize,
    /// Pressure level (computed from pending / capacity)
    pressure: Pressure,
    /// Lifetime counters
    total_accepted: u64,
    total_rejected: u64,
    total_dropped: u64,
    total_popped: u64,
    /// Per-priority drop counters
    high_dropped: u64,
    normal_dropped: u64,
    low_dropped: u64,
    /// Latency tracking (nanoseconds in queue)
    /// Last popped event's wait time (nanoTimestamp delta at pop)
    last_pop_latency_ns: u64,
    /// Rolling max latency observed
    max_pop_latency_ns: u64,
    /// Rolling sum for average computation
    total_pop_latency_ns: u64,
    /// Number of pops (for average computation)
    pop_count: u64,
};

// ============================================================
// STEP 3: Submit result with backpressure signal
// ============================================================

pub const SubmitWithPressure = struct {
    accepted: bool,
    pressure: Pressure,
    /// If dropped, which priority's queue was the victim (if drop_oldest)
    dropped_priority: ?pq.Priority = null,
};

// ============================================================
// Event Fabric State (centralized)
// ============================================================

var g_fabric_initialized: bool = false;
var g_priority_queue: ?pq.PriorityQueue = null;
var g_config: FabricConfig = .{};

// Lifetime counters
var g_total_accepted: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);
var g_total_rejected: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);
var g_total_dropped: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);
var g_total_popped: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);

// Latency tracking (updated under fabric mutex — single producer/consumer path)
var g_last_pop_latency_ns: u64 = 0;
var g_max_pop_latency_ns: u64 = 0;
var g_total_pop_latency_ns: u64 = 0;
var g_pop_count: u64 = 0;

// Enqueue timestamp table — records when each event_id was enqueued.
// This is a simple map: event_id -> enqueue_time_ns.
// For bounded memory, we use a fixed-size ring of (event_id, ts) pairs.
// Detection-side does linear lookup — acceptable because pop is rare vs push.

const LatencyEntry = struct {
    event_id: u64,
    enqueue_ns: i128,
};

const LATENCY_RING_SIZE: usize = 256;
var g_latency_ring: [LATENCY_RING_SIZE]LatencyEntry = [_]LatencyEntry{.{ .event_id = 0, .enqueue_ns = 0 }} ** LATENCY_RING_SIZE;
var g_latency_ring_idx: usize = 0;

// ============================================================
// Initialization
// ============================================================

pub fn initFabric(allocator: std.mem.Allocator, config: FabricConfig) !void {
    if (g_fabric_initialized) return;
    g_config = config;
    g_priority_queue = try pq.PriorityQueue.init(allocator, config.capacity_per_priority);
    g_fabric_initialized = true;

    // Reset metrics
    g_total_accepted.store(0, .monotonic);
    g_total_rejected.store(0, .monotonic);
    g_total_dropped.store(0, .monotonic);
    g_total_popped.store(0, .monotonic);
    g_last_pop_latency_ns = 0;
    g_max_pop_latency_ns = 0;
    g_total_pop_latency_ns = 0;
    g_pop_count = 0;
    g_latency_ring_idx = 0;

    std.log.info("[FABRIC] initialized (capacity={d}/queue, policy={s}, thresholds={d:.0}%/{d:.0}%)", .{
        config.capacity_per_priority,
        switch (config.drop_policy) {
            .block_new => "block_new",
            .drop_oldest => "drop_oldest",
            .drop_lowest_priority => "drop_lowest_priority",
        },
        @as(u32, @intFromFloat(config.medium_threshold * 100)),
        @as(u32, @intFromFloat(config.high_threshold * 100)),
    });
}

pub fn shutdownFabric(allocator: std.mem.Allocator) void {
    if (!g_fabric_initialized) return;
    if (g_priority_queue) |*queue| {
        queue.deinit(allocator);
    }
    g_priority_queue = null;
    g_fabric_initialized = false;
    std.log.info("[FABRIC] shutdown (accepted={d} rejected={d} dropped={d} popped={d})", .{
        g_total_accepted.load(.monotonic),
        g_total_rejected.load(.monotonic),
        g_total_dropped.load(.monotonic),
        g_total_popped.load(.monotonic),
    });
}

// ============================================================
// Pressure computation
// ============================================================

/// Compute current pressure level based on the MAX per-priority depth.
///
/// Why MAX (not average): if HIGH queue is 90% full but LOW queue is empty,
/// we are still under high pressure — critical events are about to drop.
/// Using average would mask this and lead to false "low pressure" signals.
pub fn currentPressure() Pressure {
    if (!g_fabric_initialized or g_priority_queue == null) return .low;
    var queue = &g_priority_queue.?;
    const stats = queue.getStats();
    const cap = g_config.capacity_per_priority;
    if (cap == 0) return .low;

    // Per-priority depth fraction (0.0 .. 1.0)
    const high_depth = @as(f32, @floatFromInt(stats.high_count)) / @as(f32, @floatFromInt(cap));
    const normal_depth = @as(f32, @floatFromInt(stats.normal_count)) / @as(f32, @floatFromInt(cap));
    const low_depth = @as(f32, @floatFromInt(stats.low_count)) / @as(f32, @floatFromInt(cap));

    const max_depth = @max(high_depth, @max(normal_depth, low_depth));

    if (max_depth >= 1.0) return .saturated;
    if (max_depth >= g_config.high_threshold) return .high;
    if (max_depth >= g_config.medium_threshold) return .medium;
    return .low;
}

// ============================================================
// Latency tracking (ring of event_id -> enqueue_ns)
// ============================================================

fn recordEnqueue(event_id: u64, enqueue_ns: i128) void {
    const idx = g_latency_ring_idx;
    g_latency_ring[idx] = .{ .event_id = event_id, .enqueue_ns = enqueue_ns };
    g_latency_ring_idx = (idx + 1) % LATENCY_RING_SIZE;
}

fn lookupAndClearLatency(event_id: u64, pop_ns: i128) u64 {
    // Linear scan — LATENCY_RING_SIZE is small (256).
    var i: usize = 0;
    while (i < LATENCY_RING_SIZE) : (i += 1) {
        if (g_latency_ring[i].event_id == event_id and g_latency_ring[i].enqueue_ns != 0) {
            const enq_ns = g_latency_ring[i].enqueue_ns;
            g_latency_ring[i].enqueue_ns = 0; // clear
            const delta = @as(u64, @intCast(@max(pop_ns - enq_ns, 0)));
            return delta;
        }
    }
    return 0; // Not found (ring overflowed)
}

// ============================================================
// Submit API
// ============================================================

/// Submit an event with full backpressure signaling.
/// STEP 3: preferred API. Caller uses returned Pressure to throttle upstream.
pub fn submitWithBackpressure(event: canonical.CanonicalEvent) SubmitWithPressure {
    if (!g_fabric_initialized) {
        return .{ .accepted = false, .pressure = .low };
    }

    // Validate event schema
    if (g_config.validate_on_submit) {
        if (!canonical.validate(&event)) {
            _ = g_total_rejected.fetchAdd(1, .monotonic);
            return .{ .accepted = false, .pressure = currentPressure() };
        }
    }

    if (g_priority_queue) |*queue| {
        // Record enqueue time for latency tracking
        recordEnqueue(event.event_id, std.time.nanoTimestamp());

        const ok = queue.push(event);
        const pressure = currentPressure();
        if (ok) {
            _ = g_total_accepted.fetchAdd(1, .monotonic);
            return .{ .accepted = true, .pressure = pressure };
        } else {
            // Queue full — apply drop policy
            _ = g_total_dropped.fetchAdd(1, .monotonic);
            return .{ .accepted = false, .pressure = .saturated };
        }
    }
    return .{ .accepted = false, .pressure = .low };
}

/// Submit an event. Simpler API for callers that don't care about pressure.
pub fn submitEvent(event: canonical.CanonicalEvent) bool {
    return submitWithBackpressure(event).accepted;
}

/// Submit a wire-format frame (for external sensors via IPC).
pub fn submitWireEvent(wire_bytes: []const u8) bool {
    if (!g_fabric_initialized) return false;
    const event = wire.deserializeEvent(wire_bytes) orelse {
        _ = g_total_rejected.fetchAdd(1, .monotonic);
        return false;
    };
    return submitEvent(event);
}

// ============================================================
// Pop API (with latency tracking)
// ============================================================

/// Pop the next event. Updates latency metrics.
pub fn popEvent() ?canonical.CanonicalEvent {
    if (!g_fabric_initialized) return null;
    if (g_priority_queue) |*queue| {
        const event = queue.pop() orelse return null;
        _ = g_total_popped.fetchAdd(1, .monotonic);

        // Compute latency
        const pop_ns = std.time.nanoTimestamp();
        const delta_ns = lookupAndClearLatency(event.event_id, pop_ns);
        if (delta_ns > 0) {
            g_last_pop_latency_ns = delta_ns;
            if (delta_ns > g_max_pop_latency_ns) {
                g_max_pop_latency_ns = delta_ns;
            }
            g_total_pop_latency_ns +%= delta_ns;
            g_pop_count +%= 1;
        }

        return event;
    }
    return null;
}

// ============================================================
// Inspection API
// ============================================================

pub fn hasEvents() bool {
    if (!g_fabric_initialized) return false;
    if (g_priority_queue) |*queue| {
        return !queue.isEmpty();
    }
    return false;
}

/// Check if the fabric is currently initialized.
pub fn isInitialized() bool {
    return g_fabric_initialized;
}

pub fn pendingCount() usize {
    if (!g_fabric_initialized) return 0;
    if (g_priority_queue) |*queue| {
        return queue.len();
    }
    return 0;
}

/// Get a unified metrics snapshot for monitoring / CLI.
pub fn getMetrics() FabricMetrics {
    if (!g_fabric_initialized or g_priority_queue == null) {
        return .{
            .initialized = false,
            .pending = 0,
            .high_pending = 0,
            .normal_pending = 0,
            .low_pending = 0,
            .capacity_per_priority = 0,
            .pressure = .low,
            .total_accepted = 0,
            .total_rejected = 0,
            .total_dropped = 0,
            .total_popped = 0,
            .high_dropped = 0,
            .normal_dropped = 0,
            .low_dropped = 0,
            .last_pop_latency_ns = 0,
            .max_pop_latency_ns = 0,
            .total_pop_latency_ns = 0,
            .pop_count = 0,
        };
    }
    var queue = &g_priority_queue.?;
    const qstats = queue.getStats();
    return .{
        .initialized = true,
        .pending = qstats.high_count + qstats.normal_count + qstats.low_count,
        .high_pending = qstats.high_count,
        .normal_pending = qstats.normal_count,
        .low_pending = qstats.low_count,
        .capacity_per_priority = g_config.capacity_per_priority,
        .pressure = currentPressure(),
        .total_accepted = g_total_accepted.load(.monotonic),
        .total_rejected = g_total_rejected.load(.monotonic),
        .total_dropped = g_total_dropped.load(.monotonic),
        .total_popped = g_total_popped.load(.monotonic),
        .high_dropped = qstats.high_dropped,
        .normal_dropped = qstats.normal_dropped,
        .low_dropped = qstats.low_dropped,
        .last_pop_latency_ns = g_last_pop_latency_ns,
        .max_pop_latency_ns = g_max_pop_latency_ns,
        .total_pop_latency_ns = g_total_pop_latency_ns,
        .pop_count = g_pop_count,
    };
}

/// Get the active configuration (read-only, for ops introspection).
pub fn getConfig() FabricConfig {
    return g_config;
}

// ============================================================
// Reset metrics (for tests / restart-without-realloc)
// ============================================================

pub fn resetMetrics() void {
    g_total_accepted.store(0, .monotonic);
    g_total_rejected.store(0, .monotonic);
    g_total_dropped.store(0, .monotonic);
    g_total_popped.store(0, .monotonic);
    g_last_pop_latency_ns = 0;
    g_max_pop_latency_ns = 0;
    g_total_pop_latency_ns = 0;
    g_pop_count = 0;
    g_latency_ring_idx = 0;
    for (&g_latency_ring) |*entry| {
        entry.event_id = 0;
        entry.enqueue_ns = 0;
    }
}

// ============================================================
// Tests
// ============================================================

test "Pressure.toString returns human-readable names" {
    try std.testing.expect(std.mem.eql(u8, Pressure.low.toString(), "low"));
    try std.testing.expect(std.mem.eql(u8, Pressure.medium.toString(), "medium"));
    try std.testing.expect(std.mem.eql(u8, Pressure.high.toString(), "high"));
    try std.testing.expect(std.mem.eql(u8, Pressure.saturated.toString(), "saturated"));
}

test "FabricConfig defaults are sensible" {
    const cfg = FabricConfig{};
    try std.testing.expect(cfg.capacity_per_priority == 256);
    try std.testing.expect(cfg.validate_on_submit == true);
    try std.testing.expect(cfg.medium_threshold == 0.50);
    try std.testing.expect(cfg.high_threshold == 0.80);
    try std.testing.expect(cfg.drop_policy == .block_new);
}

test "initFabric and shutdownFabric lifecycle" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);

    const metrics = getMetrics();
    try std.testing.expect(metrics.initialized);
    try std.testing.expect(metrics.pending == 0);
    try std.testing.expect(metrics.pressure == .low);
}

test "submitWithBackpressure accepts valid event and returns low pressure" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    var event = canonical.create(.zig_core);
    event.event_type = .block;
    const result = submitWithBackpressure(event);
    try std.testing.expect(result.accepted);
    try std.testing.expect(result.pressure == .low);
}

test "submitWithBackpressure rejects invalid event with rejected counter" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    var event = canonical.create(.zig_core);
    event.magic = 0xDEADBEEF;
    const result = submitWithBackpressure(event);
    try std.testing.expect(!result.accepted);

    const metrics = getMetrics();
    try std.testing.expect(metrics.total_rejected == 1);
    try std.testing.expect(metrics.total_accepted == 0);
}

test "currentPressure returns medium at 50% depth" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 10 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    // MAX-depth logic: push 5 events into HIGH queue = 50% of HIGH capacity => medium.
    // (Other queues remain empty; max depth across all 3 priorities = 50%.)
    var i: u32 = 0;
    while (i < 5) : (i += 1) {
        var event = canonical.create(.zig_core);
        event.event_type = .block;
        _ = submitEvent(event);
    }
    try std.testing.expect(currentPressure() == .medium);
}

test "currentPressure returns high at 80% depth" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 10 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    // MAX-depth logic: push 8 events into HIGH queue = 80% of HIGH capacity => high.
    var i: u32 = 0;
    while (i < 8) : (i += 1) {
        var event = canonical.create(.zig_core);
        event.event_type = .block;
        _ = submitEvent(event);
    }
    try std.testing.expect(currentPressure() == .high);
}

test "currentPressure returns saturated at 100% depth" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 2 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    // MAX-depth logic: fill HIGH queue to 100% (2 events in capacity-2 HIGH queue).
    var i: u32 = 0;
    while (i < 2) : (i += 1) {
        var event = canonical.create(.zig_core);
        event.event_type = .block;
        _ = submitEvent(event);
    }
    try std.testing.expect(currentPressure() == .saturated);
}

test "submitWithBackpressure returns saturated pressure on overflow" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 2 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    // Fill HIGH queue to capacity (2 events = 100% depth => saturated)
    var i: u32 = 0;
    while (i < 2) : (i += 1) {
        var event = canonical.create(.zig_core);
        event.event_type = .block;
        _ = submitEvent(event);
    }

    // 3rd event — HIGH queue is full, should be dropped with saturated pressure
    var event = canonical.create(.zig_core);
    event.event_type = .block;
    const result = submitWithBackpressure(event);
    try std.testing.expect(!result.accepted);
    try std.testing.expect(result.pressure == .saturated);

    const metrics = getMetrics();
    try std.testing.expect(metrics.total_dropped == 1);
}

test "popEvent tracks latency" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    var event = canonical.create(.zig_core);
    event.event_type = .block;
    _ = submitEvent(event);

    // Sleep briefly so latency > 0
    std.time.sleep(1_000_000); // 1ms

    const popped = popEvent();
    try std.testing.expect(popped != null);

    const metrics = getMetrics();
    try std.testing.expect(metrics.total_popped == 1);
    try std.testing.expect(metrics.pop_count == 1);
    // Latency may be 0 if lookup missed (ring race), but typically > 0
    // We don't strictly assert > 0 to avoid flaky tests on fast machines.
    try std.testing.expect(metrics.last_pop_latency_ns < 1_000_000_000); // < 1s sanity
}

test "getMetrics returns full snapshot" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    // Push 3 events
    var i: u32 = 0;
    while (i < 3) : (i += 1) {
        var e = canonical.create(.zig_core);
        e.event_type = .block;
        _ = submitEvent(e);
    }

    const metrics = getMetrics();
    try std.testing.expect(metrics.initialized);
    try std.testing.expect(metrics.pending == 3);
    try std.testing.expect(metrics.high_pending == 3);
    try std.testing.expect(metrics.total_accepted == 3);
    try std.testing.expect(metrics.capacity_per_priority == 16);
}

test "submitWireEvent uses STEP 2B explicit decode path" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    // Create event and serialize via STEP 2B explicit wire format
    var event = canonical.create(.wfp_sensor);
    event.event_type = .block;
    event.source_ip = 0xC0A80164;

    var buf: [256]u8 = undefined;
    const written = try wire.serializeEvent(&buf, &event);

    // Submit through wire path
    try std.testing.expect(submitWireEvent(buf[0..written]));

    // Verify event was enqueued
    try std.testing.expect(pendingCount() == 1);
    const popped = popEvent();
    try std.testing.expect(popped != null);
    try std.testing.expect(popped.?.source_ip == 0xC0A80164);
}

test "submitWireEvent rejects corrupted wire frame" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    var event = canonical.create(.zig_core);
    var buf: [256]u8 = undefined;
    _ = try wire.serializeEvent(&buf, &event);

    // Corrupt CRC byte
    buf[20] ^= 0xFF;
    try std.testing.expect(!submitWireEvent(&buf));

    const metrics = getMetrics();
    try std.testing.expect(metrics.total_rejected == 1);
}

test "resetMetrics clears counters but not queue contents" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);

    var e = canonical.create(.zig_core);
    e.event_type = .block;
    _ = submitEvent(e);
    _ = submitEvent(e);
    try std.testing.expect(pendingCount() == 2);

    resetMetrics();
    const metrics = getMetrics();
    try std.testing.expect(metrics.total_accepted == 0);
    try std.testing.expect(metrics.pending == 2); // Queue contents preserved
}

test "getConfig exposes active configuration" {
    try initFabric(std.testing.allocator, .{
        .capacity_per_priority = 64,
        .medium_threshold = 0.60,
        .high_threshold = 0.90,
        .drop_policy = .drop_oldest,
    });
    defer shutdownFabric(std.testing.allocator);

    const cfg = getConfig();
    try std.testing.expect(cfg.capacity_per_priority == 64);
    try std.testing.expect(cfg.medium_threshold == 0.60);
    try std.testing.expect(cfg.high_threshold == 0.90);
    try std.testing.expect(cfg.drop_policy == .drop_oldest);
}

test "STEP3: high-priority events pop before low-priority even under load" {
    try initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer shutdownFabric(std.testing.allocator);
    resetMetrics();

    // Push low-priority events
    var i: u32 = 0;
    while (i < 5) : (i += 1) {
        var e = canonical.create(.zig_core);
        e.event_type = .forward;
        e.event_id = 1000 + i;
        _ = submitEvent(e);
    }

    // Push high-priority events
    i = 0;
    while (i < 3) : (i += 1) {
        var e = canonical.create(.zig_core);
        e.event_type = .block;
        e.event_id = 2000 + i;
        _ = submitEvent(e);
    }

    // First 3 popped should be high-priority (event_id 2000..2002)
    i = 0;
    while (i < 3) : (i += 1) {
        const popped = popEvent().?;
        try std.testing.expect(popped.event_id >= 2000);
        try std.testing.expect(popped.event_type == .block);
    }
}
