//! hids_process_monitor.zig - AEGIS HIDS Process Monitor (Phase 32, AEGIS-009)
//!
//! STEP 4: Updated to use nose_integration.submit() instead of nose.submitEvent().
//! This gives every process event pressure-aware sampling + backoff behavior.
//!
//! Host-based Intrusion Detection: monitors process creation/exit events.
//! Submits host events via Nose Contract (EventSource.host_sensor).
//!
//! Blueprint principle: "Sensor ไม่ควรเป็น Detection Engine"
//! This module ONLY captures process events — detection is done by
//! DetectionManager downstream.

const std = @import("std");
const bridge_init = @import("bridge_init.zig");
const nose = @import("nose_contract.zig");
const nose_int = @import("nose_integration.zig");
const canonical = @import("canonical_event.zig");

// ============================================================
// Configuration
// ============================================================

const PROCESS_SCAN_INTERVAL_S: u64 = 5; // Scan every 5 seconds

// Suspicious process name patterns (detection is done downstream,
// but we tag events with pattern matches for context)
const SUSPICIOUS_PATTERNS = [_][]const u8{
    "mimikatz",
    "procdump",
    "pwdump",
    "nc.exe",      // netcat
    "psexec",
    "winexe",
    "wmic",
    "powershell",  // flagged for monitoring
    "cmd.exe",     // flagged for monitoring
    "rundll32",
    "regsvr32",
    "mshta",
    "cscript",
    "wscript",
};

// ============================================================
// Process Event Structure
// ============================================================

pub const ProcessEvent = struct {
    pid: u32,
    ppid: u32,
    name: [256]u8,
    name_len: usize,
    command_line: [1024]u8,
    cmd_len: usize,
    is_suspicious: bool,
    suspicious_pattern: ?[]const u8,

    pub fn getName(self: *const ProcessEvent) []const u8 {
        return self.name[0..self.name_len];
    }
};

// ============================================================
// HIDS Process Monitor
// ============================================================

var g_scan_count: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);
var g_total_processes: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);
var g_suspicious_count: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);
var g_dropped_at_source: std.atomic.Value(u64) = std.atomic.Value(u64).init(0);

/// Check if a process name matches suspicious patterns.
/// This is context tagging, NOT detection — detection is done by DetectionManager.
fn isSuspiciousName(name: []const u8) ?[]const u8 {
    // Convert to lowercase for matching
    var lower_buf: [256]u8 = undefined;
    const lower_len = @min(name.len, lower_buf.len);
    for (name[0..lower_len], 0..) |c, i| {
        lower_buf[i] = std.ascii.toLower(c);
    }
    const lower = lower_buf[0..lower_len];

    for (SUSPICIOUS_PATTERNS) |pattern| {
        if (std.mem.indexOf(u8, lower, pattern) != null) {
            return pattern;
        }
    }
    return null;
}

/// Submit a process creation event to the Event Fabric.
/// STEP 4: Uses nose_integration.submit() for pressure-aware sampling.
pub fn submitProcessCreate(pid: u32, ppid: u32, name: []const u8) void {
    _ = ppid; // reserved for future parent-child correlation
    _ = pid; // stored in reserved field for future use
    var event = nose.createEvent(.minifilter); // closest existing source for host events
    event.event_type = .session_start;
    event.payload_length = @intCast(name.len);

    // Tag with suspicious pattern if matched (context only)
    const pattern = isSuspiciousName(name);
    if (pattern != null) {
        event.context_flags |= 0x01; // bit0 = suspicious_name_match
        event.severity = 1; // Low — actual severity determined by policy
    }

    _ = g_total_processes.fetchAdd(1, .monotonic);
    if (pattern != null) {
        _ = g_suspicious_count.fetchAdd(1, .monotonic);
    }

    // STEP 4: use pressure-aware submit
    const result = nose_int.submit(event);
    switch (result) {
        .accepted, .dropped_by_fabric, .rejected => {
            // Stats already tracked inside nose_integration
        },
        .dropped_at_source => {
            _ = g_dropped_at_source.fetchAdd(1, .monotonic);
            std.log.debug("[HIDS-PROC] Event dropped at source (pressure sampling)", .{});
        },
        .not_initialized => {
            std.log.warn("[HIDS-PROC] Fabric not initialized", .{});
        },
    }
}

/// Submit a process exit event.
/// STEP 4: Uses nose_integration.submit() for pressure-aware sampling.
pub fn submitProcessExit(pid: u32) void {
    _ = pid; // reserved for future use
    var event = nose.createEvent(.minifilter);
    event.event_type = .session_end;

    _ = nose_int.submit(event);
}

/// Get statistics for monitoring.
pub fn getStats() HIDSProcessStats {
    return .{
        .total_scans = g_scan_count.load(.monotonic),
        .total_processes = g_total_processes.load(.monotonic),
        .suspicious_count = g_suspicious_count.load(.monotonic),
        .dropped_at_source = g_dropped_at_source.load(.monotonic),
    };
}

pub const HIDSProcessStats = struct {
    total_scans: u64,
    total_processes: u64,
    suspicious_count: u64,
    /// STEP 4: events dropped at source due to backpressure sampling.
    dropped_at_source: u64 = 0,
};

// ============================================================
// Tests
// ============================================================

test "isSuspiciousName detects mimikatz" {
    const result = isSuspiciousName("mimikatz.exe");
    try std.testing.expect(result != null);
    try std.testing.expect(std.mem.eql(u8, result.?, "mimikatz"));
}

test "isSuspiciousName detects PowerShell (case insensitive)" {
    const result = isSuspiciousName("POWERSHELL.EXE");
    try std.testing.expect(result != null);
    try std.testing.expect(std.mem.eql(u8, result.?, "powershell"));
}

test "isSuspiciousName returns null for benign process" {
    const result = isSuspiciousName("notepad.exe");
    try std.testing.expect(result == null);
}

test "isSuspiciousName returns null for empty name" {
    const result = isSuspiciousName("");
    try std.testing.expect(result == null);
}

test "isSuspiciousName detects psexec in path" {
    const result = isSuspiciousName("C:\\tools\\psexec.exe");
    try std.testing.expect(result != null);
    try std.testing.expect(std.mem.eql(u8, result.?, "psexec"));
}

test "submitProcessCreate updates counters" {
    // Init fabric + nose_integration for test
    try nose.initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer {
        nose.shutdownFabric(std.testing.allocator);
        // Reset counters
        g_total_processes.store(0, .monotonic);
        g_suspicious_count.store(0, .monotonic);
        g_dropped_at_source.store(0, .monotonic);
    }
    nose_int.init(.{ .seed = 42 });
    nose_int.resetStats();

    submitProcessCreate(1234, 5678, "notepad.exe");
    submitProcessCreate(1235, 5678, "mimikatz.exe");

    const stats = getStats();
    try std.testing.expect(stats.total_processes == 2);
    try std.testing.expect(stats.suspicious_count == 1);
}

test "getStats returns zeros before any events" {
    // Reset
    g_total_processes.store(0, .monotonic);
    g_suspicious_count.store(0, .monotonic);
    g_scan_count.store(0, .monotonic);
    g_dropped_at_source.store(0, .monotonic);

    const stats = getStats();
    try std.testing.expect(stats.total_processes == 0);
    try std.testing.expect(stats.suspicious_count == 0);
    try std.testing.expect(stats.dropped_at_source == 0);
}

test "STEP4: process events use nose_integration.submit (pressure-aware)" {
    try nose.initFabric(std.testing.allocator, .{ .capacity_per_priority = 16 });
    defer nose.shutdownFabric(std.testing.allocator);
    nose_int.init(.{ .seed = 42 });
    nose_int.resetStats();
    const fabric = @import("event_fabric.zig");
    fabric.resetMetrics();

    // Under low pressure, event should be accepted
    submitProcessCreate(100, 1, "notepad.exe");

    const stats = getStats();
    try std.testing.expect(stats.total_processes == 1);

    // Verify nose_integration saw the event
    const int_stats = nose_int.getSensorStats(.minifilter);
    try std.testing.expect(int_stats.total_submits == 1);
    try std.testing.expect(int_stats.accepted == 1);
}

test "STEP4: HIDSProcessStats includes dropped_at_source field" {
    const stats = HIDSProcessStats{
        .total_scans = 10,
        .total_processes = 5,
        .suspicious_count = 1,
        .dropped_at_source = 2,
    };
    try std.testing.expect(stats.dropped_at_source == 2);
}
